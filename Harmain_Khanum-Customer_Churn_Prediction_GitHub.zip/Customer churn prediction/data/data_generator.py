import pandas as pd
import numpy as np

def generate_dataset(n_samples=10000, filename="data/customers.csv"):
    np.random.seed(42)
    
    customer_ids = [f"CUST-{10000 + i}" for i in range(n_samples)]
    tenure_months = np.random.randint(1, 72, size=n_samples)
    monthly_charges = np.round(np.random.uniform(20.0, 150.0, size=n_samples), 2)
    usage_drop_pct = np.round(np.random.uniform(0.0, 0.9, size=n_samples), 2)
    support_tickets = np.random.poisson(lam=2, size=n_samples)
    days_since_last_purchase = np.random.randint(1, 120, size=n_samples)
    contract_type = np.random.choice(["Month-to-Month", "One-Year", "Two-Year"], size=n_samples, p=[0.55, 0.25, 0.20])
    payment_method = np.random.choice(["Electronic Check", "Credit Card", "Bank Transfer"], size=n_samples)
    
    churn_score = (
        (usage_drop_pct * 3.5) +
        (support_tickets * 0.4) +
        (days_since_last_purchase * 0.02) -
        (tenure_months * 0.03) +
        (contract_type == "Month-to-Month") * 1.5 +
        np.random.normal(0, 0.5, size=n_samples)
    )
    churn = (churn_score > 2.0).astype(int)
    
    df = pd.DataFrame({
        "customer_id": customer_ids,
        "tenure_months": tenure_months,
        "monthly_charges": monthly_charges,
        "usage_drop_pct": usage_drop_pct,
        "support_tickets": support_tickets,
        "days_since_last_purchase": days_since_last_purchase,
        "contract_type": contract_type,
        "payment_method": payment_method,
        "churn": churn
    })
    
    df.to_csv(filename, index=False)
    print(f"Dataset saved to {filename}")

if __name__ == "__main__":
    generate_dataset()